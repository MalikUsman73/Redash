---
name: "\U0001F4A1Anything else"
about: "For help, support, features & ideas - please use Discussions \U0001F46B "
labels: "Support Question"
---

We use GitHub only for bug reports 🐛

Anything else should be a discussion: https://github.com/getredash/redash/discussions/ 👫

🚨For support, help & questions use https://github.com/getredash/redash/discussions/categories/q-a
💡For feature requests & ideas use https://github.com/getredash/redash/discussions/categories/ideas

Alternatively, check out these resources below. Thanks! 😁.

- [Discussions](https://github.com/getredash/redash/discussions/)
- [Knowledge Base](https://redash.io/help)
